import StatsSkeleton from "./StatsSkeleton";
import TaskCardSkeleton from "./TaskCardSkeleton";

export {
  StatsSkeleton,
  TaskCardSkeleton
};
