import Dialog from "./Dialog";

export { Dialog };
